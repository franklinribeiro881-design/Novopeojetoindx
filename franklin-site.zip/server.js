import express from 'express';
import session from 'express-session';
import passport from 'passport';
import { Strategy as GoogleStrategy } from 'passport-google-oauth20';
import dotenv from 'dotenv';
import sqlite3 from 'sqlite3';
import bcrypt from 'bcrypt';
import path from 'path';
import { fileURLToPath } from 'url';

dotenv.config();
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// ---- Config DB (SQLite) ----
const db = new sqlite3.Database('./db.sqlite');
db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    googleId TEXT UNIQUE,
    name TEXT,
    email TEXT UNIQUE,
    photo TEXT,
    createdAt TEXT,
    lastLogin TEXT
  )`);
});

// ---- Passport Google OAuth ----
passport.use(new GoogleStrategy({
  clientID: process.env.GOOGLE_CLIENT_ID,
  clientSecret: process.env.GOOGLE_CLIENT_SECRET,
  callbackURL: process.env.GOOGLE_CALLBACK_URL
}, (accessToken, refreshToken, profile, done) => {
  const email = profile.emails?.[0]?.value || null;
  const name = profile.displayName || '';
  const photo = profile.photos?.[0]?.value || '';
  const googleId = profile.id;
  const now = new Date().toISOString();

  db.run(
    `INSERT INTO users (googleId, name, email, photo, createdAt, lastLogin)
     VALUES (?, ?, ?, ?, ?, ?)
     ON CONFLICT(email) DO UPDATE SET name=excluded.name, photo=excluded.photo, lastLogin=excluded.lastLogin`,
    [googleId, name, email, photo, now, now],
    (err) => {
      if (err) return done(err);
      done(null, { googleId, name, email, photo });
    }
  );
}));

passport.serializeUser((user, done) => done(null, user));
passport.deserializeUser((obj, done) => done(null, obj));

// ---- App ----
const app = express();
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: true }));

app.use(session({
  secret: process.env.SESSION_SECRET || 'troque_este_valor',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 1000 * 60 * 60 * 24 } // 1 dia
}));

app.use(passport.initialize());
app.use(passport.session());

// ---- Middlewares úteis ----
const ensureAuth = (req, res, next) => {
  if (req.isAuthenticated()) return next();
  res.redirect('/');
};

const ensureAdmin = async (req, res, next) => {
  if (req.session.isAdmin) return next();
  res.redirect('/admin/login');
};

// ---- Rotas públicas ----
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/auth/google', passport.authenticate('google', { scope: ['profile', 'email'] }));

app.get('/auth/google/callback',
  passport.authenticate('google', { failureRedirect: '/' }),
  (req, res) => {
    res.redirect('/me');
  }
);

app.get('/me', ensureAuth, (req, res) => {
  res.render('profile', { user: req.user });
});

app.get('/logout', (req, res, next) => {
  req.logout(err => {
    if (err) return next(err);
    req.session.destroy(() => res.redirect('/'));
  });
});

// ---- Admin ----
app.get('/admin/login', (req, res) => {
  res.render('admin-login', { error: null });
});

app.post('/admin/login', async (req, res) => {
  const { password } = req.body;
  const hash = process.env.ADMIN_PASSWORD_HASH;
  const ok = await bcrypt.compare(password, hash);
  if (ok) {
    req.session.isAdmin = true;
    return res.redirect('/admin');
  }
  res.status(401);
  res.render('admin-login', { error: 'Senha inválida' });
});

app.get('/admin/logout', (req, res) => {
  req.session.isAdmin = false;
  res.redirect('/');
});

app.get('/admin', ensureAdmin, (req, res) => {
  db.all('SELECT id, name, email, photo, createdAt, lastLogin FROM users ORDER BY id DESC', (err, rows) => {
    if (err) return res.status(500).send('Erro ao carregar usuários');
    res.render('admin', { users: rows });
  });
});

// ---- Start ----
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`✅ Server rodando em http://localhost:${PORT}`));
